1. Setup initial trigger( One time activity ) run CURRENT_DIR/initial.sh

check the repository at cloudbuild trigger in GCP console dashboard
3. ./ops/tag.sh <setup-env> wait for the job to complete

4. ./ops/tag.sh <setup-env> wait for the job to complete NOTE: this looks like the same first command , but this is necessary for first time only

5. ./ops/tag.sh <dev> wait for the job to complete